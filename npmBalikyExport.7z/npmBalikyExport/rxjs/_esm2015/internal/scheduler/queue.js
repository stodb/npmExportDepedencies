import { QueueAction } from './QueueAction';
import { QueueScheduler } from './QueueScheduler';
export const queue = new QueueScheduler(QueueAction);
//# sourceMappingURL=queue.js.map