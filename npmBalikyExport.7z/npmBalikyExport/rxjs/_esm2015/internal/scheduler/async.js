import { AsyncAction } from './AsyncAction';
import { AsyncScheduler } from './AsyncScheduler';
export const async = new AsyncScheduler(AsyncAction);
//# sourceMappingURL=async.js.map