export function identity(x) {
    return x;
}
//# sourceMappingURL=identity.js.map