export const errorObject = { e: {} };
//# sourceMappingURL=errorObject.js.map