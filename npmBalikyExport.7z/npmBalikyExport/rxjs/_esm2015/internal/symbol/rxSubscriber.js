export const rxSubscriber = typeof Symbol === 'function'
    ? Symbol('rxSubscriber')
    : '@@rxSubscriber_' + Math.random();
export const $$rxSubscriber = rxSubscriber;
//# sourceMappingURL=rxSubscriber.js.map