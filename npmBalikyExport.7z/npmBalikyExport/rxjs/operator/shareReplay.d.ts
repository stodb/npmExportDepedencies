export * from 'rxjs-compat/operator/shareReplay';
