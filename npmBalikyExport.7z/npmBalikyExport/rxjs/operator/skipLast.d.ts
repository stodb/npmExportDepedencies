export * from 'rxjs-compat/operator/skipLast';
