export * from 'rxjs-compat/operator/mergeScan';
