export * from 'rxjs-compat/operator/multicast';
