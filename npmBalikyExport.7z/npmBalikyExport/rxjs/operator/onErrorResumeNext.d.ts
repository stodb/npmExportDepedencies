export * from 'rxjs-compat/operator/onErrorResumeNext';
