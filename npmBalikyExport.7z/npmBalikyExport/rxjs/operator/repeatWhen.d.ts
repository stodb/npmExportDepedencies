export * from 'rxjs-compat/operator/repeatWhen';
