export * from 'rxjs-compat/operator/groupBy';
