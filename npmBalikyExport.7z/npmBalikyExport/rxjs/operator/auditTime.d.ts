export * from 'rxjs-compat/operator/auditTime';
