export * from 'rxjs-compat/operator/windowCount';
