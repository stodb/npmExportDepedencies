export * from 'rxjs-compat/operator/bufferTime';
