export * from 'rxjs-compat/operator/timeInterval';
