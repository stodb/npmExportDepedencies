export * from 'rxjs-compat/operator/share';
