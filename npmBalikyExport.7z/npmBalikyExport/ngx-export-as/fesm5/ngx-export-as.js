import { Injectable, NgModule } from '@angular/core';
import { Observable } from 'rxjs';
import html2canvas from 'html2canvas';
import { utils, write } from 'xlsx';
import { asBlob } from 'html-docx-js/dist/html-docx';
import html2pdf from 'html2pdf.js';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
window['html2canvas'] = html2canvas;
var ExportAsService = /** @class */ (function () {
    function ExportAsService() {
    }
    /**
     * Main base64 get method, it will return the file as base64 string
     * @param config your config
     */
    /**
     * Main base64 get method, it will return the file as base64 string
     * @param {?} config your config
     * @return {?}
     */
    ExportAsService.prototype.get = /**
     * Main base64 get method, it will return the file as base64 string
     * @param {?} config your config
     * @return {?}
     */
    function (config) {
        // structure method name dynamically by type
        /** @type {?} */
        var func = 'get' + config.type.toUpperCase();
        // if type supported execute and return
        if (this[func]) {
            return this[func](config);
        }
        // throw error for unsupported formats
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        function (observer) { observer.error('Export type is not supported.'); }));
    };
    /**
     * Save exported file in old javascript way
     * @param config your custom config
     * @param fileName Name of the file to be saved as
     */
    /**
     * Save exported file in old javascript way
     * @param {?} config your custom config
     * @param {?} fileName Name of the file to be saved as
     * @return {?}
     */
    ExportAsService.prototype.save = /**
     * Save exported file in old javascript way
     * @param {?} config your custom config
     * @param {?} fileName Name of the file to be saved as
     * @return {?}
     */
    function (config, fileName) {
        // set download
        config.download = true;
        // get file name with type
        config.fileName = fileName + '.' + config.type;
        return this.get(config);
    };
    /**
     * Converts content string to blob object
     * @param content string to be converted
     */
    /**
     * Converts content string to blob object
     * @param {?} content string to be converted
     * @return {?}
     */
    ExportAsService.prototype.contentToBlob = /**
     * Converts content string to blob object
     * @param {?} content string to be converted
     * @return {?}
     */
    function (content) {
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        function (observer) {
            // get content string and extract mime type
            /** @type {?} */
            var arr = content.split(',');
            /** @type {?} */
            var mime = arr[0].match(/:(.*?);/)[1];
            /** @type {?} */
            var bstr = atob(arr[1]);
            /** @type {?} */
            var n = bstr.length;
            /** @type {?} */
            var u8arr = new Uint8Array(n);
            while (n--) {
                u8arr[n] = bstr.charCodeAt(n);
            }
            observer.next(new Blob([u8arr], { type: mime }));
            observer.complete();
        }));
    };
    /**
     * Removes base64 file type from a string like "data:text/csv;base64,"
     * @param fileContent the base64 string to remove the type from
     */
    /**
     * Removes base64 file type from a string like "data:text/csv;base64,"
     * @param {?} fileContent the base64 string to remove the type from
     * @return {?}
     */
    ExportAsService.prototype.removeFileTypeFromBase64 = /**
     * Removes base64 file type from a string like "data:text/csv;base64,"
     * @param {?} fileContent the base64 string to remove the type from
     * @return {?}
     */
    function (fileContent) {
        /** @type {?} */
        var re = /^data:[^]*;base64,/g;
        /** @type {?} */
        var newContent = re[Symbol.replace](fileContent, '');
        return newContent;
    };
    /**
     * Structure the base64 file content with the file type string
     * @param fileContent file content
     * @param fileMime file mime type "text/csv"
     */
    /**
     * Structure the base64 file content with the file type string
     * @param {?} fileContent file content
     * @param {?} fileMime file mime type "text/csv"
     * @return {?}
     */
    ExportAsService.prototype.addFileTypeToBase64 = /**
     * Structure the base64 file content with the file type string
     * @param {?} fileContent file content
     * @param {?} fileMime file mime type "text/csv"
     * @return {?}
     */
    function (fileContent, fileMime) {
        return "data:" + fileMime + ";base64," + fileContent;
    };
    /**
     * create downloadable file from dataURL
     * @param fileName downloadable file name
     * @param dataURL file content as dataURL
     */
    /**
     * create downloadable file from dataURL
     * @param {?} fileName downloadable file name
     * @param {?} dataURL file content as dataURL
     * @return {?}
     */
    ExportAsService.prototype.downloadFromDataURL = /**
     * create downloadable file from dataURL
     * @param {?} fileName downloadable file name
     * @param {?} dataURL file content as dataURL
     * @return {?}
     */
    function (fileName, dataURL) {
        var _this = this;
        // create blob
        this.contentToBlob(dataURL).subscribe((/**
         * @param {?} blob
         * @return {?}
         */
        function (blob) {
            // download the blob
            _this.downloadFromBlob(blob, fileName);
        }));
    };
    /**
     * Downloads the blob object as a file
     * @param blob file object as blob
     * @param fileName downloadable file name
     */
    /**
     * Downloads the blob object as a file
     * @param {?} blob file object as blob
     * @param {?} fileName downloadable file name
     * @return {?}
     */
    ExportAsService.prototype.downloadFromBlob = /**
     * Downloads the blob object as a file
     * @param {?} blob file object as blob
     * @param {?} fileName downloadable file name
     * @return {?}
     */
    function (blob, fileName) {
        // get object url
        /** @type {?} */
        var url = window.URL.createObjectURL(blob);
        // check for microsoft internet explorer
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            // use IE download or open if the user using IE
            window.navigator.msSaveOrOpenBlob(blob, fileName);
        }
        else {
            // if not using IE then create link element
            /** @type {?} */
            var element = document.createElement('a');
            // set download attr with file name
            element.setAttribute('download', fileName);
            // set the element as hidden
            element.style.display = 'none';
            // append the body
            document.body.appendChild(element);
            // set href attr
            element.href = url;
            // click on it to start downloading
            element.click();
            // remove the link from the dom
            document.body.removeChild(element);
        }
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getPDF = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        function (observer) {
            if (!config.options) {
                config.options = {};
            }
            config.options.filename = config.fileName;
            /** @type {?} */
            var element = document.getElementById(config.elementId);
            /** @type {?} */
            var pdf = html2pdf().set(config.options).from(element, 'element');
            if (config.download) {
                pdf.save();
                observer.next();
                observer.complete();
            }
            else {
                pdf.outputPdf('datauristring').then((/**
                 * @param {?} data
                 * @return {?}
                 */
                function (data) {
                    observer.next(data);
                    observer.complete();
                }));
            }
        }));
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getPNG = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        var _this = this;
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        function (observer) {
            /** @type {?} */
            var element = document.getElementById(config.elementId);
            html2canvas(element, config.options).then((/**
             * @param {?} canvas
             * @return {?}
             */
            function (canvas) {
                /** @type {?} */
                var imgData = canvas.toDataURL('image/PNG');
                if (config.type === 'png' && config.download) {
                    _this.downloadFromDataURL(config.fileName, imgData);
                    observer.next();
                }
                else {
                    observer.next(imgData);
                }
                observer.complete();
            }), (/**
             * @param {?} err
             * @return {?}
             */
            function (err) {
                observer.error(err);
            }));
        }));
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getCSV = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        var _this = this;
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        function (observer) {
            /** @type {?} */
            var element = document.getElementById(config.elementId);
            /** @type {?} */
            var csv = [];
            /** @type {?} */
            var rows = element.querySelectorAll('table tr');
            for (var index = 0; index < rows.length; index++) {
                /** @type {?} */
                var rowElement = rows[index];
                /** @type {?} */
                var row = [];
                /** @type {?} */
                var cols = rowElement.querySelectorAll('td, th');
                for (var colIndex = 0; colIndex < cols.length; colIndex++) {
                    /** @type {?} */
                    var col = cols[colIndex];
                    row.push(col.innerText);
                }
                csv.push(row.join(','));
            }
            /** @type {?} */
            var csvContent = 'data:text/csv;base64,' + _this.btoa(csv.join('\n'));
            if (config.download) {
                _this.downloadFromDataURL(config.fileName, csvContent);
                observer.next();
            }
            else {
                observer.next(csvContent);
            }
            observer.complete();
        }));
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getTXT = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        /** @type {?} */
        var nameFrags = config.fileName.split('.');
        config.fileName = nameFrags[0] + ".txt";
        return this.getCSV(config);
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getXLS = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        var _this = this;
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        function (observer) {
            /** @type {?} */
            var element = document.getElementById(config.elementId);
            /** @type {?} */
            var ws3 = utils.table_to_sheet(element, config.options);
            /** @type {?} */
            var wb = utils.book_new();
            utils.book_append_sheet(wb, ws3, config.fileName);
            /** @type {?} */
            var out = write(wb, { type: 'base64' });
            /** @type {?} */
            var xlsContent = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,' + out;
            if (config.download) {
                _this.downloadFromDataURL(config.fileName, xlsContent);
                observer.next();
            }
            else {
                observer.next(xlsContent);
            }
            observer.complete();
        }));
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getXLSX = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        return this.getXLS(config);
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getDOCX = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        var _this = this;
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        function (observer) {
            /** @type {?} */
            var contentDocument = document.getElementById(config.elementId).outerHTML;
            /** @type {?} */
            var content = '<!DOCTYPE html>' + contentDocument;
            /** @type {?} */
            var converted = asBlob(content, config.options);
            if (config.download) {
                _this.downloadFromBlob(converted, config.fileName);
                observer.next();
                observer.complete();
            }
            else {
                /** @type {?} */
                var reader_1 = new FileReader();
                reader_1.onloadend = (/**
                 * @return {?}
                 */
                function () {
                    /** @type {?} */
                    var base64data = reader_1.result;
                    observer.next(base64data);
                    observer.complete();
                });
                reader_1.readAsDataURL(converted);
            }
        }));
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getDOC = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        return this.getDOCX(config);
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getJSON = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        var _this = this;
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        function (observer) {
            /** @type {?} */
            var data = [];
            // first row needs to be headers
            /** @type {?} */
            var headers = [];
            /** @type {?} */
            var table = (/** @type {?} */ (document.getElementById(config.elementId)));
            for (var index = 0; index < table.rows[0].cells.length; index++) {
                headers[index] = table.rows[0].cells[index].innerHTML.toLowerCase().replace(/ /gi, '');
            }
            // go through cells
            for (var i = 1; i < table.rows.length; i++) {
                /** @type {?} */
                var tableRow = table.rows[i];
                /** @type {?} */
                var rowData = {};
                for (var j = 0; j < tableRow.cells.length; j++) {
                    rowData[headers[j]] = tableRow.cells[j].innerHTML;
                }
                data.push(rowData);
            }
            /** @type {?} */
            var jsonString = JSON.stringify(data);
            /** @type {?} */
            var jsonBase64 = _this.btoa(jsonString);
            /** @type {?} */
            var dataStr = 'data:text/json;base64,' + jsonBase64;
            if (config.download) {
                _this.downloadFromDataURL(config.fileName, dataStr);
                observer.next();
            }
            else {
                observer.next(data);
            }
            observer.complete();
        }));
    };
    /**
     * @private
     * @param {?} config
     * @return {?}
     */
    ExportAsService.prototype.getXML = /**
     * @private
     * @param {?} config
     * @return {?}
     */
    function (config) {
        var _this = this;
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        function (observer) {
            /** @type {?} */
            var xml = '<?xml version="1.0" encoding="UTF-8"?><Root><Classes>';
            /** @type {?} */
            var tritem = document.getElementById(config.elementId).getElementsByTagName('tr');
            for (var i = 0; i < tritem.length; i++) {
                /** @type {?} */
                var celldata = tritem[i];
                if (celldata.cells.length > 0) {
                    xml += '<Class name="' + celldata.cells[0].textContent + '">\n';
                    for (var m = 1; m < celldata.cells.length; ++m) {
                        xml += '\t<data>' + celldata.cells[m].textContent + '</data>\n';
                    }
                    xml += '</Class>\n';
                }
            }
            xml += '</Classes></Root>';
            /** @type {?} */
            var base64 = 'data:text/xml;base64,' + _this.btoa(xml);
            if (config.download) {
                _this.downloadFromDataURL(config.fileName, base64);
                observer.next();
            }
            else {
                observer.next(base64);
            }
            observer.complete();
        }));
    };
    /**
     * @private
     * @param {?} content
     * @return {?}
     */
    ExportAsService.prototype.btoa = /**
     * @private
     * @param {?} content
     * @return {?}
     */
    function (content) {
        return btoa(unescape(encodeURIComponent(content)));
    };
    ExportAsService.decorators = [
        { type: Injectable }
    ];
    /** @nocollapse */
    ExportAsService.ctorParameters = function () { return []; };
    return ExportAsService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ExportAsModule = /** @class */ (function () {
    function ExportAsModule() {
    }
    ExportAsModule.decorators = [
        { type: NgModule, args: [{
                    providers: [ExportAsService],
                },] }
    ];
    return ExportAsModule;
}());

export { ExportAsModule, ExportAsService };
//# sourceMappingURL=ngx-export-as.js.map
