/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of ngx-export-as
 */
export { ExportAsService } from './lib/export-as.service';
export {} from './lib/export-as-config.model';
export { ExportAsModule } from './lib/export-as.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25neC1leHBvcnQtYXMvIiwic291cmNlcyI6WyJwdWJsaWNfYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFJQSxnQ0FBYyx5QkFBeUIsQ0FBQztBQUN4QyxlQUFjLDhCQUE4QixDQUFDO0FBQzdDLCtCQUFjLHdCQUF3QixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFB1YmxpYyBBUEkgU3VyZmFjZSBvZiBuZ3gtZXhwb3J0LWFzXG4gKi9cblxuZXhwb3J0ICogZnJvbSAnLi9saWIvZXhwb3J0LWFzLnNlcnZpY2UnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvZXhwb3J0LWFzLWNvbmZpZy5tb2RlbCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9leHBvcnQtYXMubW9kdWxlJztcbiJdfQ==