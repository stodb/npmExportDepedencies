export declare class ExportAsModule {
}
